package com.entity.layer3;

public class FundTransferDto {

	private String frmdate;
	private String todate;
	private String accno;
	public String getFrmdate() {
		return frmdate;
	}
	public void setFrmdate(String frmdate) {
		this.frmdate = frmdate;
	}
	public String getTodate() {
		return todate;
	}
	public void setTodate(String todate) {
		this.todate = todate;
	}
	public String getAccno() {
		return accno;
	}
	public void setAccno(String accno) {
		this.accno = accno;
	}
	
	
	
	
}
